<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="relative chart-income" style="max-height:400px;">
	<canvas id="chart-income" class="animated fadeIn" height="400"></canvas>
</div>
